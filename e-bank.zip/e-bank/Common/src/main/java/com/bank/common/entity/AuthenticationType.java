package com.bank.common.entity;

public enum AuthenticationType {
    DATABASE, GOOGLE
}
