package com.bank.common.entity;

public enum SettingCategory {
        GENERAL, MAIL_SERVER, MAIL_TEMPLATES
}
