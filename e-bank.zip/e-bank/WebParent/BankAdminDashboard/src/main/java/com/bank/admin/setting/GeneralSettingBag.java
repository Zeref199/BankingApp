package com.bank.admin.setting;

import com.bank.common.entity.Setting;
import com.bank.common.entity.SettingBag;

import java.util.List;

public class GeneralSettingBag extends SettingBag {
    public GeneralSettingBag(List<Setting> listSettings) {
        super(listSettings);
    }
}
